<?php

$_['text_foxpost_apm']                         = 'Foxpost automata';
$_['text_foxpost_apmcod']                      = 'Foxpost automata utánvéttel';
$_['text_foxpost_transfer']                    = 'Foxpost házhozszállítás';
$_['text_foxpost_transfercod']                 = 'Foxpost házhozszállítás utánvéttel';
$_['text_free']                                = 'Ingyenes!';

// Error
$_['error_country']                            = 'Hibás ország!';
$_['error_currency']                           = 'Hibás pénznem!';
$_['error_service']                            = 'Nincs engedélyezve szállítási szolgáltatás!';
