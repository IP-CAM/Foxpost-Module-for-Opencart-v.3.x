<?php

$_['text_foxpost_apm']                         = 'Foxpost APM';
$_['text_foxpost_apmcod']                      = 'Foxpost cash at APM';
$_['text_foxpost_transfer']                    = 'Foxpost delivery';
$_['text_foxpost_transfercod']                 = 'Foxpost cash on delivery';
$_['text_free']                                = 'Free!';

// Error
$_['error_country']                            = 'Invalid country!';
$_['error_currency']                           = 'Invalid currency!';
$_['error_service']                            = 'No service available!';
